import { pgTable, text, bigint, integer, serial, boolean } from "drizzle-orm/pg-core";

export const ipBansTable = pgTable("ip_bans", {
  ip: text("ip").primaryKey(),
  until: bigint("until", { mode: "number" }).notNull(),
});

export const ipStrikesTable = pgTable("ip_strikes", {
  ip: text("ip").primaryKey(),
  count: integer("count").notNull().default(1),
  lastWindowStart: bigint("last_window_start", { mode: "number" }).notNull(),
});

/** Immutable log of every ban that has been issued. Rows are never deleted;
 *  a periodic sweep removes rows older than 30 days.
 *  unbannedAt: when the ban was actually lifted (null = still tracking).
 *  reason: 'expired' (ban ran its full duration) | 'manual' (instructor unblocked).
 *  liftedEarly: true when an instructor manually removed the ban before it expired. */
export const ipBanHistoryTable = pgTable("ip_ban_history", {
  id: serial("id").primaryKey(),
  ip: text("ip").notNull(),
  bannedAt: bigint("banned_at", { mode: "number" }).notNull(),
  until: bigint("until", { mode: "number" }).notNull(),
  unbannedAt: bigint("unbanned_at", { mode: "number" }),
  reason: text("reason"),
  liftedEarly: boolean("lifted_early").notNull().default(false),
});

export type IpBan = typeof ipBansTable.$inferSelect;
export type IpStrike = typeof ipStrikesTable.$inferSelect;
export type IpBanHistory = typeof ipBanHistoryTable.$inferSelect;
