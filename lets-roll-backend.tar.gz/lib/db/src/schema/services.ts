import { pgTable, text, serial, integer, timestamp } from "drizzle-orm/pg-core";
import { instructorsTable } from "./instructors";

export const servicesTable = pgTable("services", {
  id: serial("id").primaryKey(),
  instructorId: integer("instructor_id")
    .notNull()
    .references(() => instructorsTable.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  price: integer("price").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export type InsertService = typeof servicesTable.$inferInsert;
export type Service = typeof servicesTable.$inferSelect;
