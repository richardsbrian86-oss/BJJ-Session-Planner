import { pgTable, text, serial, timestamp, boolean } from "drizzle-orm/pg-core";

export const instructorsTable = pgTable("instructors", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  slug: text("slug").notNull().unique(),
  pinHash: text("pin_hash").notNull(),
  stripeCustomerId: text("stripe_customer_id"),
  stripeAccountId: text("stripe_account_id"),
  stripeAccountEnabled: boolean("stripe_account_enabled").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export type InsertInstructor = typeof instructorsTable.$inferInsert;
export type Instructor = typeof instructorsTable.$inferSelect;
