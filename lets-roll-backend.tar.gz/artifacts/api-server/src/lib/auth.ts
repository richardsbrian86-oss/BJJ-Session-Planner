import type { Request, Response, NextFunction, RequestHandler } from "express";
import { db, instructorsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { verify } from "./token";

declare global {
  namespace Express {
    interface Request {
      instructorId?: number;
    }
  }
}

export const requireInstructor: RequestHandler = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  const xToken = req.headers["x-instructor-token"];
  const authHeader = req.headers["authorization"];
  const rawToken = xToken ?? (authHeader ? String(authHeader).replace(/^Bearer\s+/i, "") : undefined);

  if (!rawToken) {
    res.status(401).json({ error: "Missing x-instructor-token header" });
    return;
  }

  const token = String(rawToken);
  const instructorId = verify(token);

  if (instructorId === null) {
    res.status(401).json({ error: "Invalid or tampered token" });
    return;
  }

  const [instructor] = await db
    .select({ id: instructorsTable.id })
    .from(instructorsTable)
    .where(eq(instructorsTable.id, instructorId))
    .limit(1);

  if (!instructor) {
    res.status(401).json({ error: "Instructor not found" });
    return;
  }

  req.instructorId = instructorId;
  next();
};
