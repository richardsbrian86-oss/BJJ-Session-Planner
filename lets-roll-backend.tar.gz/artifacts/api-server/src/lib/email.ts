import { Resend } from "resend";

function getResend(): Resend | null {
  const key = process.env.RESEND_API_KEY;
  if (!key) return null;
  return new Resend(key);
}

function getFromAddress(): string {
  return process.env.FROM_EMAIL ?? "notifications@updates.bjjscheduler.com";
}

function escapeHtml(value: string): string {
  return value
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

export interface CancellationEmailParams {
  to: string;
  clientName: string;
  instructorName: string;
  serviceName: string;
  date: string;
  time: string;
}

function formatDate(date: string): string {
  const [year, month, day] = date.split("-").map(Number);
  const d = new Date(year, month - 1, day);
  return d.toLocaleDateString("en-US", { weekday: "long", year: "numeric", month: "long", day: "numeric" });
}

function formatTime(time: string): string {
  const [hourStr, minuteStr] = time.split(":");
  const hour = Number(hourStr);
  const minute = minuteStr ?? "00";
  const period = hour >= 12 ? "PM" : "AM";
  const displayHour = hour % 12 === 0 ? 12 : hour % 12;
  return `${displayHour}:${minute} ${period}`;
}

export interface ClientCancellationConfirmationParams {
  to: string;
  clientName: string;
  instructorName: string;
  serviceName: string;
  date: string;
  time: string;
}

export async function sendClientCancellationConfirmationEmail(params: ClientCancellationConfirmationParams): Promise<void> {
  const resend = getResend();
  if (!resend) {
    console.warn("[email] RESEND_API_KEY not set — skipping client cancellation confirmation email");
    return;
  }

  const { to, clientName, instructorName, serviceName, date, time } = params;
  const formattedDate = formatDate(date);
  const formattedTime = formatTime(time);

  const safeClientName = escapeHtml(clientName);
  const safeInstructorName = escapeHtml(instructorName);
  const safeServiceName = escapeHtml(serviceName);
  const safeFormattedDate = escapeHtml(formattedDate);
  const safeFormattedTime = escapeHtml(formattedTime);

  const subject = `Cancellation confirmed — ${formattedDate}`;

  const html = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
</head>
<body style="font-family: Arial, sans-serif; background: #f9f9f9; margin: 0; padding: 0;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background: #f9f9f9; padding: 32px 0;">
    <tr>
      <td align="center">
        <table width="560" cellpadding="0" cellspacing="0" style="background: #ffffff; border-radius: 8px; overflow: hidden; box-shadow: 0 1px 4px rgba(0,0,0,0.08);">
          <tr>
            <td style="background: #1a1a2e; padding: 24px 32px;">
              <h1 style="color: #ffffff; margin: 0; font-size: 20px; font-weight: 700;">Cancellation Confirmed</h1>
            </td>
          </tr>
          <tr>
            <td style="padding: 32px;">
              <p style="margin: 0 0 16px; color: #333; font-size: 16px;">Hi ${safeClientName},</p>
              <p style="margin: 0 0 24px; color: #555; font-size: 15px; line-height: 1.6;">
                Your cancellation request has been confirmed. The following session has been cancelled:
              </p>
              <table width="100%" cellpadding="0" cellspacing="0" style="background: #f4f4f8; border-radius: 6px; padding: 20px; margin-bottom: 24px;">
                <tr>
                  <td style="padding: 6px 0;">
                    <span style="color: #777; font-size: 13px; text-transform: uppercase; letter-spacing: 0.5px;">Service</span><br />
                    <span style="color: #222; font-size: 15px; font-weight: 600;">${safeServiceName}</span>
                  </td>
                </tr>
                <tr>
                  <td style="padding: 6px 0;">
                    <span style="color: #777; font-size: 13px; text-transform: uppercase; letter-spacing: 0.5px;">Date</span><br />
                    <span style="color: #222; font-size: 15px; font-weight: 600;">${safeFormattedDate}</span>
                  </td>
                </tr>
                <tr>
                  <td style="padding: 6px 0;">
                    <span style="color: #777; font-size: 13px; text-transform: uppercase; letter-spacing: 0.5px;">Time</span><br />
                    <span style="color: #222; font-size: 15px; font-weight: 600;">${safeFormattedTime}</span>
                  </td>
                </tr>
                <tr>
                  <td style="padding: 6px 0;">
                    <span style="color: #777; font-size: 13px; text-transform: uppercase; letter-spacing: 0.5px;">Instructor</span><br />
                    <span style="color: #222; font-size: 15px; font-weight: 600;">${safeInstructorName}</span>
                  </td>
                </tr>
              </table>
              <p style="margin: 0 0 8px; color: #555; font-size: 15px; line-height: 1.6;">
                If you'd like to rebook, please use your booking link or contact your instructor directly.
              </p>
            </td>
          </tr>
          <tr>
            <td style="background: #f4f4f8; padding: 16px 32px; text-align: center;">
              <p style="margin: 0; color: #aaa; font-size: 12px;">This is an automated message. Please do not reply to this email.</p>
            </td>
          </tr>
        </table>
      </td>
    </tr>
  </table>
</body>
</html>
`;

  const text = `Hi ${clientName},\n\nYour cancellation has been confirmed. The following session has been cancelled:\n\n- Service: ${serviceName}\n- Date: ${formattedDate}\n- Time: ${formattedTime}\n- Instructor: ${instructorName}\n\nIf you'd like to rebook, please use your booking link or contact your instructor directly.\n`;

  try {
    await resend.emails.send({
      from: getFromAddress(),
      to,
      subject,
      html,
      text,
    });
  } catch (err) {
    console.error("[email] Failed to send client cancellation confirmation email:", err);
  }
}

export interface BookingConfirmationParams {
  to: string;
  clientName: string;
  instructorName: string;
  serviceName: string;
  date: string;
  time: string;
  amountPaidCents: number;
}

export async function sendBookingConfirmationEmail(params: BookingConfirmationParams): Promise<void> {
  const resend = getResend();
  if (!resend) {
    console.warn("[email] RESEND_API_KEY not set — skipping booking confirmation email");
    return;
  }

  const { to, clientName, instructorName, serviceName, date, time, amountPaidCents } = params;
  const formattedDate = formatDate(date);
  const formattedTime = formatTime(time);
  const amountDisplay = amountPaidCents > 0
    ? `$${(amountPaidCents / 100).toFixed(2)}`
    : "No charge";

  const safeClientName = escapeHtml(clientName);
  const safeInstructorName = escapeHtml(instructorName);
  const safeServiceName = escapeHtml(serviceName);
  const safeFormattedDate = escapeHtml(formattedDate);
  const safeFormattedTime = escapeHtml(formattedTime);
  const safeAmountDisplay = escapeHtml(amountDisplay);

  const subject = `Booking confirmed — ${formattedDate}`;

  const html = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
</head>
<body style="font-family: Arial, sans-serif; background: #f9f9f9; margin: 0; padding: 0;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background: #f9f9f9; padding: 32px 0;">
    <tr>
      <td align="center">
        <table width="560" cellpadding="0" cellspacing="0" style="background: #ffffff; border-radius: 8px; overflow: hidden; box-shadow: 0 1px 4px rgba(0,0,0,0.08);">
          <tr>
            <td style="background: #1a1a2e; padding: 24px 32px;">
              <h1 style="color: #ffffff; margin: 0; font-size: 20px; font-weight: 700;">Booking Confirmed</h1>
            </td>
          </tr>
          <tr>
            <td style="padding: 32px;">
              <p style="margin: 0 0 16px; color: #333; font-size: 16px;">Hi ${safeClientName},</p>
              <p style="margin: 0 0 24px; color: #555; font-size: 15px; line-height: 1.6;">
                Your session with <strong>${safeInstructorName}</strong> has been booked. Here are your details:
              </p>
              <table width="100%" cellpadding="0" cellspacing="0" style="background: #f4f4f8; border-radius: 6px; padding: 20px; margin-bottom: 24px;">
                <tr>
                  <td style="padding: 6px 0;">
                    <span style="color: #777; font-size: 13px; text-transform: uppercase; letter-spacing: 0.5px;">Service</span><br />
                    <span style="color: #222; font-size: 15px; font-weight: 600;">${safeServiceName}</span>
                  </td>
                </tr>
                <tr>
                  <td style="padding: 6px 0;">
                    <span style="color: #777; font-size: 13px; text-transform: uppercase; letter-spacing: 0.5px;">Date</span><br />
                    <span style="color: #222; font-size: 15px; font-weight: 600;">${safeFormattedDate}</span>
                  </td>
                </tr>
                <tr>
                  <td style="padding: 6px 0;">
                    <span style="color: #777; font-size: 13px; text-transform: uppercase; letter-spacing: 0.5px;">Time</span><br />
                    <span style="color: #222; font-size: 15px; font-weight: 600;">${safeFormattedTime}</span>
                  </td>
                </tr>
                <tr>
                  <td style="padding: 6px 0;">
                    <span style="color: #777; font-size: 13px; text-transform: uppercase; letter-spacing: 0.5px;">Instructor</span><br />
                    <span style="color: #222; font-size: 15px; font-weight: 600;">${safeInstructorName}</span>
                  </td>
                </tr>
                <tr>
                  <td style="padding: 6px 0;">
                    <span style="color: #777; font-size: 13px; text-transform: uppercase; letter-spacing: 0.5px;">Amount Paid</span><br />
                    <span style="color: #222; font-size: 15px; font-weight: 600;">${safeAmountDisplay}</span>
                  </td>
                </tr>
              </table>
              <p style="margin: 0 0 8px; color: #555; font-size: 15px; line-height: 1.6;">
                We look forward to seeing you! If you need to make any changes, please contact your instructor directly.
              </p>
            </td>
          </tr>
          <tr>
            <td style="background: #f4f4f8; padding: 16px 32px; text-align: center;">
              <p style="margin: 0; color: #aaa; font-size: 12px;">This is an automated message. Please do not reply to this email.</p>
            </td>
          </tr>
        </table>
      </td>
    </tr>
  </table>
</body>
</html>
`;

  const text = `Hi ${clientName},\n\nYour session with ${instructorName} has been booked.\n\nSession details:\n- Service: ${serviceName}\n- Date: ${formattedDate}\n- Time: ${formattedTime}\n- Instructor: ${instructorName}\n- Amount Paid: ${amountDisplay}\n\nWe look forward to seeing you! If you need to make any changes, please contact your instructor directly.\n`;

  try {
    await resend.emails.send({
      from: getFromAddress(),
      to,
      subject,
      html,
      text,
    });
  } catch (err) {
    console.error("[email] Failed to send booking confirmation email:", err);
  }
}

export interface SuspiciousLoginAlertParams {
  ip: string;
  slug: string;
  failureCount: number;
  windowMs: number;
}

export async function sendSuspiciousLoginAlert(params: SuspiciousLoginAlertParams): Promise<void> {
  const alertEmail = process.env.ALERT_EMAIL;
  if (!alertEmail) {
    return;
  }

  const resend = getResend();
  if (!resend) {
    return;
  }

  const { ip, slug, failureCount, windowMs } = params;
  const windowMinutes = Math.round(windowMs / 60_000);
  const safeIp = escapeHtml(ip);
  const safeSlug = escapeHtml(slug);
  const timestamp = new Date().toUTCString();

  const subject = `[Security Alert] ${failureCount} failed login attempts from ${ip}`;

  const html = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
</head>
<body style="font-family: Arial, sans-serif; background: #f9f9f9; margin: 0; padding: 0;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background: #f9f9f9; padding: 32px 0;">
    <tr>
      <td align="center">
        <table width="560" cellpadding="0" cellspacing="0" style="background: #ffffff; border-radius: 8px; overflow: hidden; box-shadow: 0 1px 4px rgba(0,0,0,0.08);">
          <tr>
            <td style="background: #7f1d1d; padding: 24px 32px;">
              <h1 style="color: #ffffff; margin: 0; font-size: 20px; font-weight: 700;">Security Alert — Suspicious Login Activity</h1>
            </td>
          </tr>
          <tr>
            <td style="padding: 32px;">
              <p style="margin: 0 0 16px; color: #333; font-size: 15px; line-height: 1.6;">
                A high number of failed login attempts has been detected. Details:
              </p>
              <table width="100%" cellpadding="0" cellspacing="0" style="background: #fef2f2; border-radius: 6px; padding: 20px; margin-bottom: 24px;">
                <tr>
                  <td style="padding: 6px 0;">
                    <span style="color: #777; font-size: 13px; text-transform: uppercase; letter-spacing: 0.5px;">IP Address</span><br />
                    <span style="color: #222; font-size: 15px; font-weight: 600; font-family: monospace;">${safeIp}</span>
                  </td>
                </tr>
                <tr>
                  <td style="padding: 6px 0;">
                    <span style="color: #777; font-size: 13px; text-transform: uppercase; letter-spacing: 0.5px;">Slug Targeted</span><br />
                    <span style="color: #222; font-size: 15px; font-weight: 600; font-family: monospace;">${safeSlug}</span>
                  </td>
                </tr>
                <tr>
                  <td style="padding: 6px 0;">
                    <span style="color: #777; font-size: 13px; text-transform: uppercase; letter-spacing: 0.5px;">Failure Count</span><br />
                    <span style="color: #991b1b; font-size: 15px; font-weight: 600;">${failureCount} failures in the last ${windowMinutes} minutes</span>
                  </td>
                </tr>
                <tr>
                  <td style="padding: 6px 0;">
                    <span style="color: #777; font-size: 13px; text-transform: uppercase; letter-spacing: 0.5px;">Detected At</span><br />
                    <span style="color: #222; font-size: 15px; font-weight: 600;">${timestamp}</span>
                  </td>
                </tr>
              </table>
              <p style="margin: 0 0 8px; color: #555; font-size: 14px; line-height: 1.6;">
                If this activity looks suspicious, consider blocking the IP or reviewing your server logs for more detail.
              </p>
            </td>
          </tr>
          <tr>
            <td style="background: #f4f4f8; padding: 16px 32px; text-align: center;">
              <p style="margin: 0; color: #aaa; font-size: 12px;">This is an automated security alert from BJJ Training Scheduler.</p>
            </td>
          </tr>
        </table>
      </td>
    </tr>
  </table>
</body>
</html>
`;

  const text = `Security Alert — Suspicious Login Activity\n\nA high number of failed login attempts has been detected.\n\nIP Address: ${ip}\nSlug Targeted: ${slug}\nFailure Count: ${failureCount} failures in the last ${windowMinutes} minutes\nDetected At: ${timestamp}\n\nIf this looks suspicious, consider blocking the IP or reviewing your server logs.\n`;

  try {
    await resend.emails.send({
      from: getFromAddress(),
      to: alertEmail,
      subject,
      html,
      text,
    });
  } catch (err) {
    console.error("[email] Failed to send suspicious login alert email:", err);
  }
}

export async function sendCancellationEmail(params: CancellationEmailParams): Promise<void> {
  const resend = getResend();
  if (!resend) {
    console.warn("[email] RESEND_API_KEY not set — skipping cancellation email");
    return;
  }

  const { to, clientName, instructorName, serviceName, date, time } = params;
  const formattedDate = formatDate(date);
  const formattedTime = formatTime(time);

  const safeClientName = escapeHtml(clientName);
  const safeInstructorName = escapeHtml(instructorName);
  const safeServiceName = escapeHtml(serviceName);
  const safeFormattedDate = escapeHtml(formattedDate);
  const safeFormattedTime = escapeHtml(formattedTime);

  const subject = `Your session has been cancelled — ${formattedDate}`;

  const html = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
</head>
<body style="font-family: Arial, sans-serif; background: #f9f9f9; margin: 0; padding: 0;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background: #f9f9f9; padding: 32px 0;">
    <tr>
      <td align="center">
        <table width="560" cellpadding="0" cellspacing="0" style="background: #ffffff; border-radius: 8px; overflow: hidden; box-shadow: 0 1px 4px rgba(0,0,0,0.08);">
          <tr>
            <td style="background: #1a1a2e; padding: 24px 32px;">
              <h1 style="color: #ffffff; margin: 0; font-size: 20px; font-weight: 700;">Session Cancelled</h1>
            </td>
          </tr>
          <tr>
            <td style="padding: 32px;">
              <p style="margin: 0 0 16px; color: #333; font-size: 16px;">Hi ${safeClientName},</p>
              <p style="margin: 0 0 24px; color: #555; font-size: 15px; line-height: 1.6;">
                We wanted to let you know that your upcoming session with <strong>${safeInstructorName}</strong> has been cancelled.
              </p>
              <table width="100%" cellpadding="0" cellspacing="0" style="background: #f4f4f8; border-radius: 6px; padding: 20px; margin-bottom: 24px;">
                <tr>
                  <td style="padding: 6px 0;">
                    <span style="color: #777; font-size: 13px; text-transform: uppercase; letter-spacing: 0.5px;">Service</span><br />
                    <span style="color: #222; font-size: 15px; font-weight: 600;">${safeServiceName}</span>
                  </td>
                </tr>
                <tr>
                  <td style="padding: 6px 0;">
                    <span style="color: #777; font-size: 13px; text-transform: uppercase; letter-spacing: 0.5px;">Date</span><br />
                    <span style="color: #222; font-size: 15px; font-weight: 600;">${safeFormattedDate}</span>
                  </td>
                </tr>
                <tr>
                  <td style="padding: 6px 0;">
                    <span style="color: #777; font-size: 13px; text-transform: uppercase; letter-spacing: 0.5px;">Time</span><br />
                    <span style="color: #222; font-size: 15px; font-weight: 600;">${safeFormattedTime}</span>
                  </td>
                </tr>
                <tr>
                  <td style="padding: 6px 0;">
                    <span style="color: #777; font-size: 13px; text-transform: uppercase; letter-spacing: 0.5px;">Instructor</span><br />
                    <span style="color: #222; font-size: 15px; font-weight: 600;">${safeInstructorName}</span>
                  </td>
                </tr>
              </table>
              <p style="margin: 0 0 8px; color: #555; font-size: 15px; line-height: 1.6;">
                If you have any questions, please reach out to your instructor directly.
              </p>
            </td>
          </tr>
          <tr>
            <td style="background: #f4f4f8; padding: 16px 32px; text-align: center;">
              <p style="margin: 0; color: #aaa; font-size: 12px;">This is an automated message. Please do not reply to this email.</p>
            </td>
          </tr>
        </table>
      </td>
    </tr>
  </table>
</body>
</html>
`;

  const text = `Hi ${clientName},\n\nYour session with ${instructorName} has been cancelled.\n\nSession details:\n- Service: ${serviceName}\n- Date: ${formattedDate}\n- Time: ${formattedTime}\n- Instructor: ${instructorName}\n\nIf you have any questions, please reach out to your instructor directly.\n`;

  try {
    await resend.emails.send({
      from: getFromAddress(),
      to,
      subject,
      html,
      text,
    });
  } catch (err) {
    console.error("[email] Failed to send cancellation email:", err);
  }
}
