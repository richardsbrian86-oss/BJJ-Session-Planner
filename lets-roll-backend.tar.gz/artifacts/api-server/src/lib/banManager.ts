/**
 * IP Ban Manager
 *
 * Tracks consecutive rate-limit window exhaustions per IP.
 * One strike is counted per exhausted window (not per blocked request).
 * After MAX_STRIKES consecutive exhausted windows, the IP is banned for BAN_DURATION_MS.
 * Strikes reset when a full window passes without an exhaustion.
 * Banned IPs receive 403 + Retry-After.
 *
 * Bans and strikes are persisted in Postgres so they survive server restarts.
 * Expired bans are moved to ip_ban_history rather than deleted, giving the
 * instructor a 30-day audit trail of past offenders.
 *
 * IP resolution: uses req.ip, which respects app.set('trust proxy', ...).
 * Do NOT call this with a manually parsed x-forwarded-for value.
 */

import type { Request, Response, NextFunction } from "express";
import { db, ipBansTable, ipStrikesTable, ipBanHistoryTable } from "@workspace/db";
import { eq, lt, sql } from "drizzle-orm";

const MAX_STRIKES = Number(process.env.BAN_MAX_STRIKES ?? 3);
export const BAN_DURATION_MS = Number(process.env.BAN_DURATION_MS ?? 60 * 60 * 1000);
const CLEANUP_INTERVAL_MS = 10 * 60 * 1000;
const HISTORY_RETENTION_MS = 30 * 24 * 60 * 60 * 1000; // 30 days

/**
 * Move a ban into the history table with unbannedAt and reason, then delete it.
 * Exported so the admin DELETE route can call it directly for manual unbans.
 */
export async function archiveBan(
  ip: string,
  until: number,
  reason: "expired" | "manual" = "expired",
): Promise<void> {
  const unbannedAt = Date.now();
  const bannedAt = until - BAN_DURATION_MS;
  const liftedEarly = reason === "manual";
  await db
    .insert(ipBanHistoryTable)
    .values({ ip, bannedAt, until, unbannedAt, reason, liftedEarly });
  await db.delete(ipBansTable).where(eq(ipBansTable.ip, ip));
}

/**
 * Periodically:
 *  1. Move expired ip_bans rows into ip_ban_history.
 *  2. Purge ip_ban_history rows older than 30 days so the table stays lean.
 */
function scheduleCleanup(): void {
  setInterval(async () => {
    try {
      const now = Date.now();

      // Fetch expired bans so we can archive them
      const expired = await db
        .select()
        .from(ipBansTable)
        .where(lt(ipBansTable.until, now));

      for (const ban of expired) {
        await archiveBan(ban.ip, ban.until, "expired");
      }

      // Prune history older than 30 days
      await db
        .delete(ipBanHistoryTable)
        .where(lt(ipBanHistoryTable.bannedAt, now - HISTORY_RETENTION_MS));
    } catch {
      // non-fatal — expired rows are ignored on read anyway
    }
  }, CLEANUP_INTERVAL_MS).unref();
}

scheduleCleanup();

/**
 * Call this from the express-rate-limit handler when a window is exhausted.
 * Pass req.ip so the IP source is consistent with the rate limiter's key.
 * windowMs must match the rate limiter's windowMs.
 *
 * This function is safe to call as fire-and-forget (`void recordExhaustion(...)`):
 * all DB errors are caught internally so they never produce unhandled rejections.
 */
export async function recordExhaustion(ip: string, windowMs: number): Promise<void> {
  try {
    const now = Date.now();
    const currentWindowStart = Math.floor(now / windowMs) * windowMs;

    // Single atomic UPSERT — eliminates the read-then-write race under concurrent traffic.
    // The CASE expression runs entirely inside Postgres, so two simultaneous requests
    // from the same IP will each get a distinct incremented count rather than both
    // reading count=N and both writing count=N+1.
    //
    // Three cases handled atomically:
    //   • Same window  → no change (idempotent per-window strike counting)
    //   • Gap > 1 window → reset to 1 (strike streak broken)
    //   • Consecutive window → increment by 1
    const [row] = await db
      .insert(ipStrikesTable)
      .values({ ip, count: 1, lastWindowStart: currentWindowStart })
      .onConflictDoUpdate({
        target: ipStrikesTable.ip,
        set: {
          count: sql`CASE
            WHEN ${ipStrikesTable.lastWindowStart} = excluded.last_window_start
              THEN ${ipStrikesTable.count}
            WHEN excluded.last_window_start > ${ipStrikesTable.lastWindowStart} + ${windowMs}
              THEN 1
            ELSE ${ipStrikesTable.count} + 1
          END`,
          lastWindowStart: sql`CASE
            WHEN ${ipStrikesTable.lastWindowStart} = excluded.last_window_start
              THEN ${ipStrikesTable.lastWindowStart}
            ELSE excluded.last_window_start
          END`,
        },
      })
      .returning();

    if (row.count >= MAX_STRIKES) {
      const until = now + BAN_DURATION_MS;
      await db
        .insert(ipBansTable)
        .values({ ip, until })
        .onConflictDoUpdate({
          target: ipBansTable.ip,
          set: { until },
        });
      await db.delete(ipStrikesTable).where(eq(ipStrikesTable.ip, ip));
    }
  } catch {
    // Non-fatal: if the DB is unavailable, strikes are skipped for this window.
    // The middleware's ban check also fails open, so traffic is never blocked
    // due to a DB outage.
  }
}

/** Express middleware — mount before rate limiters so bans are enforced first. */
export async function banCheckMiddleware(
  req: Request,
  res: Response,
  next: NextFunction,
): Promise<void> {
  const ip = req.ip ?? "unknown";

  try {
    const [ban] = await db
      .select()
      .from(ipBansTable)
      .where(eq(ipBansTable.ip, ip));

    if (ban) {
      const now = Date.now();
      if (now < ban.until) {
        const retryAfterSecs = Math.ceil((ban.until - now) / 1000);
        res.set("Retry-After", String(retryAfterSecs));
        res.status(403).json({
          error:
            "Your IP has been temporarily blocked due to repeated policy violations. Please try again later.",
        });
        return;
      }
      // Ban expired — move to history before removing
      await archiveBan(ban.ip, ban.until, "expired");
    }
  } catch {
    // If the DB is unavailable, fail open rather than blocking all traffic
  }

  next();
}
