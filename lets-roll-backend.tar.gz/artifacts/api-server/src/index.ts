import app from "./app";
import { logger } from "./lib/logger";
import { startAuthFailureCleanup } from "./lib/authAudit";

// Safety nets — log unexpected errors instead of crashing.
// The pg-pool 'error' handler in lib/db covers the primary crash vector;
// these catch anything else that slips through.
process.on("uncaughtException", (err) => {
  logger.error({ err }, "Uncaught exception — process will continue");
});

process.on("unhandledRejection", (reason) => {
  logger.error({ reason }, "Unhandled promise rejection");
});

const rawPort = process.env["PORT"];

if (!rawPort) {
  throw new Error(
    "PORT environment variable is required but was not provided.",
  );
}

const port = Number(rawPort);

if (Number.isNaN(port) || port <= 0) {
  throw new Error(`Invalid PORT value: "${rawPort}"`);
}

app.listen(port, (err) => {
  if (err) {
    logger.error({ err }, "Error listening on port");
    process.exit(1);
  }

  logger.info({ port }, "Server listening");
  startAuthFailureCleanup();
});
