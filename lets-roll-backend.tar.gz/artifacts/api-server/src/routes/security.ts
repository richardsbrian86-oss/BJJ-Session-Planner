import { Router } from "express";
import type { Request, Response } from "express";
import { db, authFailuresTable, authFailureHistoryTable, instructorsTable } from "@workspace/db";
import { eq, gt, lt, and, gte } from "drizzle-orm";
import { requireInstructor } from "../lib/auth";

const router = Router();

router.use(requireInstructor);

const ALERT_WINDOW_MS = Number(process.env.AUTH_ALERT_WINDOW_MS ?? 10 * 60 * 1000);
const ALERT_THRESHOLD = Number(process.env.AUTH_ALERT_THRESHOLD ?? 5);
const HISTORY_RETENTION_MS = 24 * 60 * 60 * 1000;

router.get("/events", async (req: Request, res: Response) => {
  try {
    const [instructor] = await db
      .select({ slug: instructorsTable.slug })
      .from(instructorsTable)
      .where(eq(instructorsTable.id, req.instructorId!))
      .limit(1);

    if (!instructor) {
      res.status(401).json({ error: "Instructor not found" });
      return;
    }

    const now = Date.now();
    const windowCutoff = now - ALERT_WINDOW_MS;
    const historyCutoff = now - HISTORY_RETENTION_MS;

    const [activeRows, expiredRows, historyRows] = await Promise.all([
      // Active windows: within the current detection window
      db
        .select({
          ip: authFailuresTable.ip,
          count: authFailuresTable.count,
          windowStart: authFailuresTable.windowStart,
          alertedAt: authFailuresTable.alertedAt,
        })
        .from(authFailuresTable)
        .where(
          and(
            eq(authFailuresTable.slug, instructor.slug),
            gt(authFailuresTable.windowStart, windowCutoff),
          ),
        )
        .orderBy(authFailuresTable.windowStart),

      // Expired windows still in auth_failures (alerted bursts waiting for
      // cooldown to expire). These are omitted from the active view but
      // must appear in the history timeline so there is no gap.
      db
        .select({
          ip: authFailuresTable.ip,
          count: authFailuresTable.count,
          windowStart: authFailuresTable.windowStart,
          alertedAt: authFailuresTable.alertedAt,
        })
        .from(authFailuresTable)
        .where(
          and(
            eq(authFailuresTable.slug, instructor.slug),
            lt(authFailuresTable.windowStart, windowCutoff),
            gte(authFailuresTable.windowStart, historyCutoff),
          ),
        ),

      // Fully archived bursts from the last 24 hours
      db
        .select({
          ip: authFailureHistoryTable.ip,
          count: authFailureHistoryTable.count,
          windowStart: authFailureHistoryTable.windowStart,
          windowEnd: authFailureHistoryTable.windowEnd,
          alertedAt: authFailureHistoryTable.alertedAt,
        })
        .from(authFailureHistoryTable)
        .where(
          and(
            eq(authFailureHistoryTable.slug, instructor.slug),
            gte(authFailureHistoryTable.windowEnd, historyCutoff),
          ),
        )
        .orderBy(authFailureHistoryTable.windowEnd),
    ]);

    // Merge expired auth_failures rows and archived history rows.
    // Expired rows use now as windowEnd since they haven't been archived yet.
    // Deduplicate by (ip, windowStart) so that a row already archived (rare
    // race between window reset and cleanup) does not appear twice.
    const archivedKey = new Set(
      historyRows.map((r) => `${r.ip}:${r.windowStart}`),
    );

    const expiredHistory = expiredRows
      .filter((r) => !archivedKey.has(`${r.ip}:${r.windowStart}`))
      .map((r) => ({
        ip: r.ip,
        count: r.count,
        windowStart: r.windowStart,
        windowEnd: now,
        alerted: r.alertedAt !== null,
        alertedAt: r.alertedAt ?? null,
      }));

    const archivedHistory = historyRows.map((r) => ({
      ip: r.ip,
      count: r.count,
      windowStart: r.windowStart,
      windowEnd: r.windowEnd,
      alerted: r.alertedAt !== null,
      alertedAt: r.alertedAt ?? null,
    }));

    // Combine and sort newest-first
    const history = [...expiredHistory, ...archivedHistory].sort(
      (a, b) => b.windowEnd - a.windowEnd,
    );

    res.json({
      alertThreshold: ALERT_THRESHOLD,
      windowMs: ALERT_WINDOW_MS,
      events: activeRows.map((r) => ({
        ip: r.ip,
        count: r.count,
        windowStart: r.windowStart,
        alerted: r.alertedAt !== null,
        alertedAt: r.alertedAt ?? null,
      })),
      history,
    });
  } catch {
    res.status(500).json({ error: "Failed to retrieve security events" });
  }
});

router.get("/cross-account-events", async (req: Request, res: Response) => {
  try {
    const [instructor] = await db
      .select({ slug: instructorsTable.slug })
      .from(instructorsTable)
      .where(eq(instructorsTable.id, req.instructorId!))
      .limit(1);

    if (!instructor) {
      res.status(401).json({ error: "Instructor not found" });
      return;
    }

    const now = Date.now();
    const windowCutoff = now - ALERT_WINDOW_MS;

    // Return all active failures NOT belonging to this instructor's own slug.
    // An IP may target multiple slugs; each (slug, ip) row is independent.
    const activeRows = await db
      .select({
        slug: authFailuresTable.slug,
        ip: authFailuresTable.ip,
        count: authFailuresTable.count,
        windowStart: authFailuresTable.windowStart,
        alertedAt: authFailuresTable.alertedAt,
      })
      .from(authFailuresTable)
      .where(gt(authFailuresTable.windowStart, windowCutoff))
      .orderBy(authFailuresTable.windowStart);

    // Exclude the authenticated instructor's own slug in-process.
    // Each (slug, ip) row is independent — an IP may attack multiple slugs
    // simultaneously, so we filter by slug equality, not by IP.
    const foreign = activeRows.filter((r) => r.slug !== instructor.slug);

    res.json({
      alertThreshold: ALERT_THRESHOLD,
      windowMs: ALERT_WINDOW_MS,
      events: foreign.map((r) => ({
        slug: r.slug,
        ip: r.ip,
        count: r.count,
        windowStart: r.windowStart,
        alerted: r.alertedAt !== null,
        alertedAt: r.alertedAt ?? null,
      })),
    });
  } catch {
    res.status(500).json({ error: "Failed to retrieve cross-account security events" });
  }
});

export default router;
