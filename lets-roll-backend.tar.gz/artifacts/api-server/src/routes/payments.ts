import { Router } from "express";
import type { Request, Response } from "express";
import type Stripe from "stripe";
import { db, sessionsTable, servicesTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import { requireInstructor } from "../lib/auth";
import { tryGetStripeClient } from "../lib/stripe";

const router = Router();

router.post("/create-intent", requireInstructor, async (req: Request, res: Response) => {
  const stripe = await tryGetStripeClient();
  if (!stripe) {
    res.status(503).json({ error: "Stripe is not configured" });
    return;
  }

  const { sessionId, currency = "usd" } = req.body as {
    sessionId?: number;
    currency?: string;
  };

  if (!sessionId) {
    res.status(400).json({ error: "sessionId is required" });
    return;
  }

  const [session] = await db
    .select()
    .from(sessionsTable)
    .where(
      and(
        eq(sessionsTable.id, Number(sessionId)),
        eq(sessionsTable.instructorId, req.instructorId!)
      )
    )
    .limit(1);

  if (!session) {
    res.status(404).json({ error: "Session not found" });
    return;
  }

  let amount: number;
  if (session.packageCount != null && session.packageTotal != null) {
    amount = Math.round(session.packageTotal * 0.8);
  } else {
    amount = session.servicePrice;
  }

  if (amount <= 0) {
    res.status(400).json({ error: "Session has no chargeable amount" });
    return;
  }

  const paymentIntent = await stripe.paymentIntents.create({
    amount,
    currency: String(currency),
    description: `${session.serviceName} for ${session.clientName}`,
    metadata: {
      sessionId: String(session.id),
      instructorId: String(req.instructorId),
    },
  });

  await db
    .update(sessionsTable)
    .set({ paymentIntentId: paymentIntent.id })
    .where(
      and(
        eq(sessionsTable.id, session.id),
        eq(sessionsTable.instructorId, req.instructorId!)
      )
    );

  res.json({ clientSecret: paymentIntent.client_secret, id: paymentIntent.id });
});

router.post("/create-subscription", requireInstructor, async (req: Request, res: Response) => {
  const stripe = await tryGetStripeClient();
  if (!stripe) {
    res.status(503).json({ error: "Stripe is not configured" });
    return;
  }

  const { email, serviceId, sessionId, interval = "monthly" } = req.body as {
    email?: string;
    serviceId?: number;
    sessionId?: number;
    interval?: "weekly" | "monthly";
  };

  if (!email || !serviceId || !sessionId) {
    res.status(400).json({ error: "email, serviceId, and sessionId are required" });
    return;
  }

  const [service] = await db
    .select()
    .from(servicesTable)
    .where(
      and(
        eq(servicesTable.id, Number(serviceId)),
        eq(servicesTable.instructorId, req.instructorId!)
      )
    )
    .limit(1);

  if (!service) {
    res.status(404).json({ error: "Service not found" });
    return;
  }

  const [session] = await db
    .select()
    .from(sessionsTable)
    .where(
      and(
        eq(sessionsTable.id, Number(sessionId)),
        eq(sessionsTable.instructorId, req.instructorId!)
      )
    )
    .limit(1);

  if (!session) {
    res.status(404).json({ error: "Session not found" });
    return;
  }

  const stripeInterval: Stripe.PriceCreateParams.Recurring.Interval =
    interval === "weekly" ? "week" : "month";

  const customers = await stripe.customers.list({ email, limit: 1 });
  let customer: Stripe.Customer;
  if (customers.data.length > 0) {
    customer = customers.data[0];
  } else {
    customer = await stripe.customers.create({ email });
  }

  const price = await stripe.prices.create({
    unit_amount: service.price,
    currency: "usd",
    recurring: { interval: stripeInterval },
    product_data: { name: service.name },
  });

  const subscription = await stripe.subscriptions.create({
    customer: customer.id,
    items: [{ price: price.id }],
    payment_behavior: "default_incomplete",
    payment_settings: { save_default_payment_method: "on_subscription" },
    expand: ["latest_invoice", "pending_setup_intent"],
  });

  await db
    .update(sessionsTable)
    .set({ subscriptionId: subscription.id })
    .where(
      and(
        eq(sessionsTable.id, session.id),
        eq(sessionsTable.instructorId, req.instructorId!)
      )
    );

  let clientSecret: string | null = null;

  const latestInvoice = subscription.latest_invoice;
  if (latestInvoice && typeof latestInvoice !== "string") {
    if (latestInvoice.confirmation_secret?.client_secret) {
      clientSecret = latestInvoice.confirmation_secret.client_secret;
    }
  }

  if (!clientSecret) {
    const psi = subscription.pending_setup_intent;
    if (psi && typeof psi !== "string") {
      clientSecret = psi.client_secret;
    }
  }

  res.json({
    subscriptionId: subscription.id,
    clientSecret,
  });
});

router.post("/webhook", async (req: Request, res: Response) => {
  const stripe = await tryGetStripeClient();
  if (!stripe) {
    res.status(503).json({ error: "Stripe is not configured" });
    return;
  }

  const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;

  if (!webhookSecret && process.env.NODE_ENV !== "development") {
    res.status(503).json({ error: "Webhook secret is required in production" });
    return;
  }

  let event: Stripe.Event;

  if (webhookSecret) {
    const sig = req.headers["stripe-signature"];
    if (!sig) {
      res.status(400).json({ error: "Missing stripe-signature header" });
      return;
    }
    try {
      const rawBody = (req as Request & { rawBody?: Buffer }).rawBody;
      event = stripe.webhooks.constructEvent(
        rawBody ?? Buffer.from(JSON.stringify(req.body)),
        sig,
        webhookSecret
      );
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : "Unknown error";
      res.status(400).json({ error: `Webhook signature verification failed: ${msg}` });
      return;
    }
  } else {
    event = req.body as Stripe.Event;
  }

  switch (event.type) {
    case "payment_intent.succeeded": {
      const pi = event.data.object as Stripe.PaymentIntent;
      if (pi.id) {
        await db
          .update(sessionsTable)
          .set({ paymentStatus: "paid" })
          .where(eq(sessionsTable.paymentIntentId, pi.id));
      }
      break;
    }
    case "invoice.paid": {
      const invoice = event.data.object as Stripe.Invoice;
      const subObj = invoice.parent?.subscription_details?.subscription;
      const subId =
        subObj == null
          ? null
          : typeof subObj === "string"
            ? subObj
            : subObj.id;
      if (subId) {
        await db
          .update(sessionsTable)
          .set({ paymentStatus: "paid" })
          .where(eq(sessionsTable.subscriptionId, subId));
      }
      break;
    }
    default:
      break;
  }

  res.json({ received: true });
});

export default router;
