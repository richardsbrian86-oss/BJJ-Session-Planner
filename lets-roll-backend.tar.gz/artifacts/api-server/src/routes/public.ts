import { Router, type IRouter } from "express";
import { db, instructorsTable, servicesTable, availabilityTable, sessionsTable } from "@workspace/db";
import { and, eq, notInArray } from "drizzle-orm";
import type Stripe from "stripe";
import { sendBookingConfirmationEmail, sendClientCancellationConfirmationEmail } from "../lib/email";
import { tryGetStripeClient, getStripePublishableKey, isStripeConfigured } from "../lib/stripe";
import rateLimit from "express-rate-limit";

const router: IRouter = Router();

const publicBookingLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 30,
  standardHeaders: "draft-8",
  legacyHeaders: false,
  message: { error: "Too many requests. Please try again later." },
});

const VALID_PACKAGE_COUNTS = new Set([1, 4, 6, 8, 10]);
const PACKAGE_DISCOUNT = 0.2;

function computePackageTotal(unitPrice: number, packageCount: number): number {
  if (!VALID_PACKAGE_COUNTS.has(packageCount)) {
    throw new Error(`Invalid package count: ${packageCount}. Must be one of 1, 4, 6, 8, 10.`);
  }
  const subtotal = unitPrice * packageCount;
  const discount = packageCount > 1 ? subtotal * PACKAGE_DISCOUNT : 0;
  return Math.round(subtotal - discount);
}

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

// Returns the Stripe publishable key for use by client-side apps.
router.get("/stripe-key", async (_req, res) => {
  try {
    const publishableKey = await getStripePublishableKey();
    res.json({ publishableKey });
  } catch {
    res.status(503).json({ error: "Stripe is not configured" });
  }
});

router.get("/booking/:token", async (req, res) => {
  const { token } = req.params;

  if (!UUID_RE.test(token)) {
    res.status(404).json({ error: "Booking not found" });
    return;
  }

  const [session] = await db
    .select()
    .from(sessionsTable)
    .where(eq(sessionsTable.cancellationToken, token))
    .limit(1);

  if (!session) {
    res.status(404).json({ error: "Booking not found" });
    return;
  }

  const [instructor] = await db
    .select({ id: instructorsTable.id, name: instructorsTable.name, slug: instructorsTable.slug })
    .from(instructorsTable)
    .where(eq(instructorsTable.id, session.instructorId))
    .limit(1);

  if (!instructor) {
    res.status(404).json({ error: "Instructor not found" });
    return;
  }

  res.json({
    session: {
      id: session.id,
      date: session.date,
      time: session.time,
      status: session.status,
      serviceName: session.serviceName,
      servicePrice: session.servicePrice,
      packageCount: session.packageCount,
      packageTotal: session.packageTotal,
      clientName: session.clientName,
      notes: session.notes,
      createdAt: session.createdAt,
    },
    instructor: {
      name: instructor.name,
      slug: instructor.slug,
    },
  });
});

router.delete("/booking/:token", async (req, res) => {
  const { token } = req.params;

  if (!UUID_RE.test(token)) {
    res.status(404).json({ error: "Booking not found" });
    return;
  }

  const [session] = await db
    .select()
    .from(sessionsTable)
    .where(eq(sessionsTable.cancellationToken, token))
    .limit(1);

  if (!session) {
    res.status(404).json({ error: "Booking not found" });
    return;
  }

  if (session.status === "cancelled") {
    res.status(409).json({ error: "This booking is already cancelled." });
    return;
  }

  if (session.status === "completed") {
    res.status(409).json({ error: "Completed sessions cannot be cancelled." });
    return;
  }

  await db
    .update(sessionsTable)
    .set({ status: "cancelled", updatedAt: new Date() })
    .where(eq(sessionsTable.id, session.id));

  if (session.clientEmail) {
    const [instructor] = await db
      .select({ name: instructorsTable.name })
      .from(instructorsTable)
      .where(eq(instructorsTable.id, session.instructorId))
      .limit(1);

    void sendClientCancellationConfirmationEmail({
      to: session.clientEmail,
      clientName: session.clientName ?? "there",
      instructorName: instructor?.name ?? "your instructor",
      serviceName: session.serviceName ?? "Session",
      date: session.date,
      time: session.time,
    });
  }

  res.json({ success: true });
});

router.get("/:slug", async (req, res) => {
  const { slug } = req.params;

  const [instructor] = await db
    .select({
      id: instructorsTable.id,
      name: instructorsTable.name,
      slug: instructorsTable.slug,
      stripeAccountId: instructorsTable.stripeAccountId,
      stripeAccountEnabled: instructorsTable.stripeAccountEnabled,
    })
    .from(instructorsTable)
    .where(eq(instructorsTable.slug, slug))
    .limit(1);

  if (!instructor) {
    res.status(404).json({ error: "Instructor not found" });
    return;
  }

  const [services, availability, stripeEnabled] = await Promise.all([
    db
      .select()
      .from(servicesTable)
      .where(eq(servicesTable.instructorId, instructor.id)),
    db
      .select()
      .from(availabilityTable)
      .where(eq(availabilityTable.instructorId, instructor.id)),
    isStripeConfigured(),
  ]);

  res.json({
    instructor: {
      id: instructor.id,
      name: instructor.name,
      slug: instructor.slug,
    },
    services,
    availability,
    stripeEnabled,
    stripeConnected: !!instructor.stripeAccountId && instructor.stripeAccountEnabled,
  });
});

router.get("/:slug/slots", async (req, res) => {
  const { slug } = req.params;
  const { date } = req.query as { date?: string };

  if (!date || !/^\d{4}-\d{2}-\d{2}$/.test(date)) {
    res.status(400).json({ error: "A valid date (YYYY-MM-DD) is required." });
    return;
  }

  const [instructor] = await db
    .select({ id: instructorsTable.id })
    .from(instructorsTable)
    .where(eq(instructorsTable.slug, slug))
    .limit(1);

  if (!instructor) {
    res.status(404).json({ error: "Instructor not found" });
    return;
  }

  const [year, month, day] = date.split("-").map(Number);
  const parsedDate = new Date(year, month - 1, day);
  const dayOfWeek = String(parsedDate.getDay());

  const [avail] = await db
    .select()
    .from(availabilityTable)
    .where(
      and(
        eq(availabilityTable.instructorId, instructor.id),
        eq(availabilityTable.day, dayOfWeek),
        eq(availabilityTable.enabled, true)
      )
    )
    .limit(1);

  if (!avail) {
    res.json({ slots: [] });
    return;
  }

  const timeToMinutes = (t: string): number => {
    const [h, m] = t.split(":").map(Number);
    return h * 60 + m;
  };

  const startMin = timeToMinutes(avail.startTime);
  const endMin = timeToMinutes(avail.endTime);
  const duration = avail.sessionDurationMinutes;

  const allSlots: string[] = [];
  let cur = startMin;
  while (cur + duration <= endMin) {
    const h = Math.floor(cur / 60).toString().padStart(2, "0");
    const m = (cur % 60).toString().padStart(2, "0");
    allSlots.push(`${h}:${m}`);
    cur += duration;
  }

  const bookedSessions = await db
    .select({ time: sessionsTable.time })
    .from(sessionsTable)
    .where(
      and(
        eq(sessionsTable.instructorId, instructor.id),
        eq(sessionsTable.date, date),
        notInArray(sessionsTable.status, ["cancelled", "no_show"])
      )
    );

  const bookedTimes = new Set(bookedSessions.map((s) => s.time));
  const availableSlots = allSlots.filter((slot) => !bookedTimes.has(slot));

  res.json({ slots: availableSlots });
});

router.post("/:slug/create-intent", publicBookingLimiter, async (req, res) => {
  const { slug } = req.params;

  const stripe = await tryGetStripeClient();
  if (!stripe) {
    res.status(503).json({ error: "Online payments are not configured for this portal." });
    return;
  }

  const [instructor] = await db
    .select({
      id: instructorsTable.id,
      name: instructorsTable.name,
      stripeAccountId: instructorsTable.stripeAccountId,
      stripeAccountEnabled: instructorsTable.stripeAccountEnabled,
    })
    .from(instructorsTable)
    .where(eq(instructorsTable.slug, slug))
    .limit(1);

  if (!instructor) {
    res.status(404).json({ error: "Instructor not found" });
    return;
  }

  const { serviceId, packageCount = 1, clientName } = req.body as {
    serviceId?: number;
    packageCount?: number;
    clientName?: string;
  };

  if (!serviceId || !clientName) {
    res.status(400).json({ error: "serviceId and clientName are required" });
    return;
  }

  const [service] = await db
    .select()
    .from(servicesTable)
    .where(eq(servicesTable.id, serviceId))
    .limit(1);

  if (!service || service.instructorId !== instructor.id) {
    res.status(404).json({ error: "Service not found" });
    return;
  }

  let amount: number;
  try {
    amount = computePackageTotal(service.price, packageCount);
  } catch (err) {
    const message = err instanceof Error ? err.message : "Invalid package configuration.";
    res.status(400).json({ error: message });
    return;
  }

  const intentParams: Parameters<typeof stripe.paymentIntents.create>[0] = {
    amount,
    currency: "usd",
    description: `${service.name} with ${instructor.name} for ${clientName}`,
    metadata: {
      instructorId: String(instructor.id),
      instructorSlug: slug,
      serviceId: String(service.id),
      serviceName: service.name,
      servicePrice: String(service.price),
      packageCount: String(packageCount),
      computedTotal: String(amount),
      clientName,
    },
  };

  if (instructor.stripeAccountId && instructor.stripeAccountEnabled) {
    intentParams.transfer_data = { destination: instructor.stripeAccountId };
  }

  const paymentIntent = await stripe.paymentIntents.create(intentParams);

  res.json({ clientSecret: paymentIntent.client_secret, id: paymentIntent.id });
});

router.post("/:slug/create-subscription", async (req, res) => {
  const { slug } = req.params;

  const stripe = await tryGetStripeClient();
  if (!stripe) {
    res.status(503).json({ error: "Online payments are not configured for this portal." });
    return;
  }

  const [instructor] = await db
    .select({
      id: instructorsTable.id,
      name: instructorsTable.name,
      stripeAccountId: instructorsTable.stripeAccountId,
      stripeAccountEnabled: instructorsTable.stripeAccountEnabled,
    })
    .from(instructorsTable)
    .where(eq(instructorsTable.slug, slug))
    .limit(1);

  if (!instructor) {
    res.status(404).json({ error: "Instructor not found" });
    return;
  }

  const { email, serviceId, packageCount = 1, interval = "monthly" } = req.body as {
    email?: string;
    serviceId?: number;
    packageCount?: number;
    interval?: "weekly" | "monthly";
  };

  if (!email || !serviceId) {
    res.status(400).json({ error: "email and serviceId are required" });
    return;
  }

  const [service] = await db
    .select()
    .from(servicesTable)
    .where(eq(servicesTable.id, serviceId))
    .limit(1);

  if (!service || service.instructorId !== instructor.id) {
    res.status(404).json({ error: "Service not found" });
    return;
  }

  let monthlyAmount: number;
  try {
    monthlyAmount = computePackageTotal(service.price, packageCount);
  } catch (err) {
    const message = err instanceof Error ? err.message : "Invalid package configuration.";
    res.status(400).json({ error: message });
    return;
  }

  const stripeInterval: Stripe.PriceCreateParams.Recurring.Interval =
    interval === "weekly" ? "week" : "month";

  const customers = await stripe.customers.list({ email, limit: 1 });
  let customer: Stripe.Customer;
  if (customers.data.length > 0) {
    customer = customers.data[0];
  } else {
    customer = await stripe.customers.create({ email });
  }

  const price = await stripe.prices.create({
    unit_amount: monthlyAmount,
    currency: "usd",
    recurring: { interval: stripeInterval },
    product_data: { name: `${service.name} with ${instructor.name}` },
    metadata: {
      instructorSlug: slug,
      serviceId: String(service.id),
      serviceName: service.name,
      packageCount: String(packageCount),
    },
  });

  const subscriptionParams: Parameters<typeof stripe.subscriptions.create>[0] = {
    customer: customer.id,
    items: [{ price: price.id }],
    payment_behavior: "default_incomplete",
    payment_settings: { save_default_payment_method: "on_subscription" },
    expand: ["latest_invoice", "pending_setup_intent"],
    metadata: {
      instructorId: String(instructor.id),
      instructorSlug: slug,
      serviceId: String(service.id),
      serviceName: service.name,
      servicePrice: String(service.price),
      packageCount: String(packageCount),
    },
  };

  if (instructor.stripeAccountId && instructor.stripeAccountEnabled) {
    subscriptionParams.transfer_data = { destination: instructor.stripeAccountId };
  }

  const subscription = await stripe.subscriptions.create(subscriptionParams);

  let clientSecret: string | null = null;

  const latestInvoice = subscription.latest_invoice;
  if (latestInvoice && typeof latestInvoice !== "string") {
    if (latestInvoice.confirmation_secret?.client_secret) {
      clientSecret = latestInvoice.confirmation_secret.client_secret;
    }
  }

  if (!clientSecret) {
    const psi = subscription.pending_setup_intent;
    if (psi && typeof psi !== "string") {
      clientSecret = psi.client_secret;
    }
  }

  res.json({ subscriptionId: subscription.id, clientSecret });
});

router.post("/:slug/session", publicBookingLimiter, async (req, res) => {
  const { slug } = req.params;

  const stripe = await tryGetStripeClient();

  const [instructor] = await db
    .select({ id: instructorsTable.id, name: instructorsTable.name })
    .from(instructorsTable)
    .where(eq(instructorsTable.slug, slug))
    .limit(1);

  if (!instructor) {
    res.status(404).json({ error: "Instructor not found" });
    return;
  }

  const {
    clientName,
    clientEmail,
    clientPhone,
    date,
    time,
    paymentIntentId,
    subscriptionId,
    notes,
  } = req.body as {
    clientName?: string;
    clientEmail?: string;
    clientPhone?: string;
    date?: string;
    time?: string;
    paymentIntentId?: string;
    subscriptionId?: string;
    notes?: string;
  };

  if (!clientName || !date || !time) {
    res.status(400).json({ error: "clientName, date, and time are required" });
    return;
  }

  const dateParts = /^(\d{4})-(\d{2})-(\d{2})$/.exec(date);
  if (!dateParts) {
    res.status(400).json({ error: "Invalid date format. Expected YYYY-MM-DD." });
    return;
  }
  const parsedDate = new Date(
    Number(dateParts[1]),
    Number(dateParts[2]) - 1,
    Number(dateParts[3])
  );
  const dayOfWeek = String(parsedDate.getDay());

  const [avail] = await db
    .select()
    .from(availabilityTable)
    .where(
      and(
        eq(availabilityTable.instructorId, instructor.id),
        eq(availabilityTable.day, dayOfWeek),
        eq(availabilityTable.enabled, true)
      )
    )
    .limit(1);

  if (!avail) {
    res.status(400).json({ error: "Instructor is not available on this day." });
    return;
  }

  const timeToMinutes = (t: string): number => {
    const [h, m] = t.split(":").map(Number);
    return h * 60 + m;
  };
  const requestedMin = timeToMinutes(time);
  const windowStart = timeToMinutes(avail.startTime);
  const windowEnd = timeToMinutes(avail.endTime);

  if (requestedMin < windowStart || requestedMin + avail.sessionDurationMinutes > windowEnd) {
    res.status(400).json({ error: "Requested time is outside instructor's available hours." });
    return;
  }

  const [conflictingSession] = await db
    .select({ id: sessionsTable.id })
    .from(sessionsTable)
    .where(
      and(
        eq(sessionsTable.instructorId, instructor.id),
        eq(sessionsTable.date, date),
        eq(sessionsTable.time, time),
        notInArray(sessionsTable.status, ["cancelled", "no_show"])
      )
    )
    .limit(1);

  if (conflictingSession) {
    res.status(409).json({ error: "This time slot is no longer available. Please choose another time." });
    return;
  }

  if (!paymentIntentId && !subscriptionId) {
    if (stripe) {
      res.status(400).json({ error: "Payment verification is required to complete a booking." });
      return;
    }

    const {
      serviceId,
      packageCount: pkgCount = 1,
    } = req.body as { serviceId?: number; packageCount?: number };

    let resolvedServiceName = "Session";
    let resolvedServicePrice = 0;
    let resolvedPackageCount = pkgCount;
    let resolvedPackageTotal = 0;

    if (serviceId) {
      const [svc] = await db
        .select()
        .from(servicesTable)
        .where(and(eq(servicesTable.id, serviceId), eq(servicesTable.instructorId, instructor.id)))
        .limit(1);
      if (svc) {
        resolvedServiceName = svc.name;
        resolvedServicePrice = svc.price;
        resolvedPackageTotal = Math.round(
          svc.price * resolvedPackageCount * (resolvedPackageCount > 1 ? (1 - PACKAGE_DISCOUNT) : 1)
        );
      }
    }

    const [session] = await db
      .insert(sessionsTable)
      .values({
        instructorId: instructor.id,
        clientName,
        clientEmail: clientEmail || null,
        clientPhone: clientPhone || null,
        date,
        time,
        status: "scheduled",
        serviceName: resolvedServiceName,
        servicePrice: resolvedServicePrice,
        packageCount: resolvedPackageCount,
        packageTotal: resolvedPackageTotal,
        paymentStatus: "pending",
        paymentIntentId: null,
        subscriptionId: null,
        notes: notes || null,
      })
      .returning();

    if (clientEmail) {
      void sendBookingConfirmationEmail({
        to: clientEmail,
        clientName,
        instructorName: instructor.name,
        serviceName: resolvedServiceName,
        date,
        time,
        amountPaidCents: 0,
      });
    }

    res.status(201).json(session);
    return;
  }

  if (!stripe) {
    res.status(503).json({ error: "Online payment verification is not configured." });
    return;
  }

  let serviceName: string;
  let servicePrice: number;
  let packageCount: number;
  let packageTotal: number;

  if (paymentIntentId) {
    const [existingSession] = await db
      .select({ id: sessionsTable.id })
      .from(sessionsTable)
      .where(eq(sessionsTable.paymentIntentId, paymentIntentId))
      .limit(1);

    if (existingSession) {
      res.status(409).json({ error: "This payment has already been used for a booking." });
      return;
    }

    let intent: Stripe.PaymentIntent;
    try {
      intent = await stripe.paymentIntents.retrieve(paymentIntentId);
    } catch {
      res.status(400).json({ error: "Could not verify payment. Please try again." });
      return;
    }

    if (intent.status !== "succeeded") {
      res.status(400).json({ error: "Payment has not been completed successfully." });
      return;
    }

    if (intent.metadata.instructorSlug !== slug) {
      res.status(403).json({ error: "This payment was not made for this instructor." });
      return;
    }

    serviceName = intent.metadata.serviceName || "Session";
    servicePrice = Number(intent.metadata.servicePrice) || 0;
    packageCount = Number(intent.metadata.packageCount) || 1;
    packageTotal = intent.amount;

  } else {
    const [existingSession] = await db
      .select({ id: sessionsTable.id })
      .from(sessionsTable)
      .where(eq(sessionsTable.subscriptionId, subscriptionId!))
      .limit(1);

    if (existingSession) {
      res.status(409).json({ error: "This subscription has already been used for a booking." });
      return;
    }

    let sub: Stripe.Subscription;
    try {
      sub = await stripe.subscriptions.retrieve(subscriptionId!);
    } catch {
      res.status(400).json({ error: "Could not verify subscription. Please try again." });
      return;
    }

    if (!["active", "trialing"].includes(sub.status)) {
      res.status(400).json({ error: "Subscription is not active. Please complete payment." });
      return;
    }

    if (sub.metadata.instructorSlug !== slug) {
      res.status(403).json({ error: "This subscription was not created for this instructor." });
      return;
    }

    const item = sub.items.data[0];
    serviceName = sub.metadata.serviceName || "Session";
    servicePrice = Number(sub.metadata.servicePrice) || 0;
    packageCount = Number(sub.metadata.packageCount) || 1;
    packageTotal = item?.price.unit_amount || 0;
  }

  const [session] = await db
    .insert(sessionsTable)
    .values({
      instructorId: instructor.id,
      clientName,
      clientEmail: clientEmail || null,
      clientPhone: clientPhone || null,
      date,
      time,
      status: "scheduled",
      serviceName,
      servicePrice,
      packageCount,
      packageTotal,
      paymentStatus: "paid",
      paymentIntentId: paymentIntentId || null,
      subscriptionId: subscriptionId || null,
      notes: notes || null,
    })
    .returning();

  if (clientEmail) {
    void sendBookingConfirmationEmail({
      to: clientEmail,
      clientName,
      instructorName: instructor.name,
      serviceName,
      date,
      time,
      amountPaidCents: packageTotal,
    });
  }

  res.status(201).json(session);
});

export default router;
