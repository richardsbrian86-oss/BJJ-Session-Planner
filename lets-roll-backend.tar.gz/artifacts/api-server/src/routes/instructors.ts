import { Router } from "express";
import type { Request, Response } from "express";
import { db, instructorsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { scrypt, randomBytes, timingSafeEqual } from "crypto";
import { generateSlug } from "../lib/slug";
import { sign } from "../lib/token";
import rateLimit from "express-rate-limit";
import { recordExhaustion } from "../lib/banManager";
import { recordLoginFailure, recordRateLimitHit } from "../lib/authAudit";

const router = Router();

const LOGIN_WINDOW_MS = 15 * 60 * 1000;
const REGISTER_WINDOW_MS = 15 * 60 * 1000;

const loginLimiter = rateLimit({
  windowMs: LOGIN_WINDOW_MS,
  limit: 10,
  standardHeaders: "draft-8",
  legacyHeaders: false,
  message: { error: "Too many login attempts. Please try again later." },
  handler(req, res, next, options) {
    const ip = req.ip ?? "unknown";
    void recordExhaustion(ip, LOGIN_WINDOW_MS);
    recordRateLimitHit(ip, "login");
    res.status(options.statusCode).json(options.message);
  },
});

const registerLimiter = rateLimit({
  windowMs: REGISTER_WINDOW_MS,
  limit: 5,
  standardHeaders: "draft-8",
  legacyHeaders: false,
  message: { error: "Too many registration attempts. Please try again later." },
  handler(req, res, next, options) {
    const ip = req.ip ?? "unknown";
    void recordExhaustion(ip, REGISTER_WINDOW_MS);
    recordRateLimitHit(ip, "register");
    res.status(options.statusCode).json(options.message);
  },
});

const SCRYPT_PARAMS = { N: 16384, r: 8, p: 1 };
const KEY_LEN = 32;

function scryptAsync(password: string, salt: string, keylen: number): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    scrypt(password, salt, keylen, SCRYPT_PARAMS, (err, derived) => {
      if (err) reject(err);
      else resolve(derived);
    });
  });
}

async function hashPin(pin: string): Promise<string> {
  const salt = randomBytes(16).toString("hex");
  const derived = await scryptAsync(pin, salt, KEY_LEN);
  return `${salt}:${derived.toString("hex")}`;
}

async function verifyPin(pin: string, stored: string): Promise<boolean> {
  const [salt, hash] = stored.split(":");
  if (!salt || !hash) return false;
  const derived = await scryptAsync(pin, salt, KEY_LEN);
  const storedBuf = Buffer.from(hash, "hex");
  if (derived.length !== storedBuf.length) return false;
  return timingSafeEqual(derived, storedBuf);
}

router.post("/register", registerLimiter, async (req: Request, res: Response) => {
  const { name, pin } = req.body as { name?: string; pin?: string };
  if (!name || !pin) {
    res.status(400).json({ error: "name and pin are required" });
    return;
  }
  if (!/^\d{4,}$/.test(String(pin))) {
    res.status(400).json({ error: "PIN must be at least 4 numeric digits" });
    return;
  }

  const pinHash = await hashPin(String(pin));

  for (let attempt = 0; attempt < 5; attempt++) {
    const slug = generateSlug(String(name));
    try {
      const [instructor] = await db
        .insert(instructorsTable)
        .values({ name: String(name), slug, pinHash })
        .returning({
          id: instructorsTable.id,
          slug: instructorsTable.slug,
          name: instructorsTable.name,
        });

      const token = sign(instructor.id);
      res.status(201).json({
        id: instructor.id,
        slug: instructor.slug,
        name: instructor.name,
        token,
      });
      return;
    } catch (err: unknown) {
      const isUniqueViolation =
        err instanceof Error &&
        "code" in err &&
        (err as NodeJS.ErrnoException & { code: string }).code === "23505";

      if (!isUniqueViolation) throw err;
    }
  }

  res.status(500).json({ error: "Failed to generate a unique slug after multiple attempts" });
});

router.post("/login", loginLimiter, async (req: Request, res: Response) => {
  const { slug, pin } = req.body as { slug?: string; pin?: string };
  if (!slug || !pin) {
    res.status(400).json({ error: "slug and pin are required" });
    return;
  }

  const [instructor] = await db
    .select()
    .from(instructorsTable)
    .where(eq(instructorsTable.slug, String(slug)))
    .limit(1);

  if (!instructor) {
    recordLoginFailure(req.ip ?? "unknown", String(slug));
    res.status(401).json({ error: "Invalid credentials" });
    return;
  }

  const valid = await verifyPin(String(pin), instructor.pinHash);
  if (!valid) {
    recordLoginFailure(req.ip ?? "unknown", String(slug));
    res.status(401).json({ error: "Invalid credentials" });
    return;
  }

  const token = sign(instructor.id);

  res.json({
    id: instructor.id,
    slug: instructor.slug,
    name: instructor.name,
    token,
  });
});

export default router;
