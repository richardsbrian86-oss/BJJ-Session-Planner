import crypto from "crypto";
import { Router } from "express";
import type { Request, Response } from "express";
import { db, sessionsTable, instructorsTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import { requireInstructor } from "../lib/auth";
import { sendCancellationEmail } from "../lib/email";

const router = Router();

router.use(requireInstructor);

router.get("/", async (req: Request, res: Response) => {
  const sessions = await db
    .select()
    .from(sessionsTable)
    .where(eq(sessionsTable.instructorId, req.instructorId!));
  res.json(sessions);
});

router.post("/", async (req: Request, res: Response) => {
  const {
    clientName,
    clientEmail,
    clientPhone,
    date,
    time,
    serviceName,
    servicePrice,
    packageCount,
    packageTotal,
    notes,
  } = req.body as {
    clientName?: string;
    clientEmail?: string;
    clientPhone?: string;
    date?: string;
    time?: string;
    serviceName?: string;
    servicePrice?: number;
    packageCount?: number;
    packageTotal?: number;
    notes?: string;
  };

  if (!clientName || !date || !time || !serviceName) {
    res
      .status(400)
      .json({ error: "clientName, date, time, serviceName are required" });
    return;
  }

  const [session] = await db
    .insert(sessionsTable)
    .values({
      instructorId: req.instructorId!,
      clientName,
      clientEmail: clientEmail ?? null,
      clientPhone: clientPhone ?? null,
      date,
      time,
      serviceName,
      servicePrice: servicePrice != null ? Number(servicePrice) : 0,
      packageCount: packageCount != null ? Number(packageCount) : null,
      packageTotal: packageTotal != null ? Number(packageTotal) : null,
      notes: notes ?? null,
      cancellationToken: crypto.randomUUID(),
    })
    .returning();

  res.status(201).json(session);
});

router.patch("/:id", async (req: Request<{ id: string }>, res: Response) => {
  const sessionId = parseInt(req.params.id, 10);
  if (isNaN(sessionId)) {
    res.status(400).json({ error: "Invalid session ID" });
    return;
  }

  const {
    status,
    date,
    time,
    clientName,
    clientEmail,
    clientPhone,
    notes,
    serviceName,
    servicePrice,
    packageCount,
    packageTotal,
    paymentStatus,
    paymentIntentId,
    calendarEventId,
  } = req.body as {
    status?: "scheduled" | "completed" | "cancelled" | "no_show";
    date?: string;
    time?: string;
    clientName?: string;
    clientEmail?: string;
    clientPhone?: string;
    notes?: string;
    serviceName?: string;
    servicePrice?: number;
    packageCount?: number;
    packageTotal?: number;
    paymentStatus?: "pending" | "paid" | "failed" | "refunded";
    paymentIntentId?: string;
    calendarEventId?: string;
  };

  type SessionPatch = Partial<{
    status: "scheduled" | "completed" | "cancelled" | "no_show";
    date: string;
    time: string;
    clientName: string;
    clientEmail: string;
    clientPhone: string;
    notes: string;
    serviceName: string;
    servicePrice: number;
    packageCount: number;
    packageTotal: number;
    paymentStatus: "pending" | "paid" | "failed" | "refunded";
    paymentIntentId: string;
    calendarEventId: string;
    updatedAt: Date;
  }>;

  const updates: SessionPatch = { updatedAt: new Date() };
  if (status !== undefined) updates.status = status;
  if (date !== undefined) updates.date = date;
  if (time !== undefined) updates.time = time;
  if (clientName !== undefined) updates.clientName = clientName;
  if (clientEmail !== undefined) updates.clientEmail = clientEmail;
  if (clientPhone !== undefined) updates.clientPhone = clientPhone;
  if (notes !== undefined) updates.notes = notes;
  if (serviceName !== undefined) updates.serviceName = serviceName;
  if (servicePrice !== undefined) updates.servicePrice = Number(servicePrice);
  if (packageCount !== undefined) updates.packageCount = Number(packageCount);
  if (packageTotal !== undefined) updates.packageTotal = Number(packageTotal);
  if (paymentStatus !== undefined) updates.paymentStatus = paymentStatus;
  if (paymentIntentId !== undefined) updates.paymentIntentId = paymentIntentId;
  if (calendarEventId !== undefined) updates.calendarEventId = calendarEventId;

  const [existing] = await db
    .select({ status: sessionsTable.status, clientEmail: sessionsTable.clientEmail })
    .from(sessionsTable)
    .where(
      and(
        eq(sessionsTable.id, sessionId),
        eq(sessionsTable.instructorId, req.instructorId!)
      )
    )
    .limit(1);

  if (!existing) {
    res.status(404).json({ error: "Session not found" });
    return;
  }

  const [updated] = await db
    .update(sessionsTable)
    .set(updates)
    .where(
      and(
        eq(sessionsTable.id, sessionId),
        eq(sessionsTable.instructorId, req.instructorId!)
      )
    )
    .returning();

  if (!updated) {
    res.status(404).json({ error: "Session not found" });
    return;
  }

  if (
    updates.status === "cancelled" &&
    existing.status !== "cancelled" &&
    updated.clientEmail
  ) {
    const [instructor] = await db
      .select({ name: instructorsTable.name })
      .from(instructorsTable)
      .where(eq(instructorsTable.id, req.instructorId!))
      .limit(1);

    void sendCancellationEmail({
      to: updated.clientEmail,
      clientName: updated.clientName,
      instructorName: instructor?.name ?? "Your instructor",
      serviceName: updated.serviceName,
      date: updated.date,
      time: updated.time,
    });
  }

  res.json(updated);
});

router.delete("/:id", async (req: Request<{ id: string }>, res: Response) => {
  const sessionId = parseInt(req.params.id, 10);
  if (isNaN(sessionId)) {
    res.status(400).json({ error: "Invalid session ID" });
    return;
  }

  const [deleted] = await db
    .delete(sessionsTable)
    .where(
      and(
        eq(sessionsTable.id, sessionId),
        eq(sessionsTable.instructorId, req.instructorId!)
      )
    )
    .returning({ id: sessionsTable.id });

  if (!deleted) {
    res.status(404).json({ error: "Session not found" });
    return;
  }

  res.status(204).send();
});

export default router;
