import { Router } from "express";
import { requireInstructor } from "../lib/auth";
import { db, ipBansTable, ipBanHistoryTable } from "@workspace/db";
import { eq, gt, gte, desc } from "drizzle-orm";
import { archiveBan } from "../lib/banManager";

const router = Router();

const HISTORY_RETENTION_MS = 30 * 24 * 60 * 60 * 1000; // 30 days

router.use(requireInstructor);

/**
 * GET /api/admin/bans
 * Returns currently active bans.
 * When ?history=true is passed, returns past bans from the last 30 days instead.
 */
router.get("/bans", async (req, res) => {
  if (req.query.history === "true") {
    try {
      const cutoff = Date.now() - HISTORY_RETENTION_MS;

      const rows = await db
        .select({
          ip: ipBanHistoryTable.ip,
          bannedAt: ipBanHistoryTable.bannedAt,
          until: ipBanHistoryTable.until,
          unbannedAt: ipBanHistoryTable.unbannedAt,
          reason: ipBanHistoryTable.reason,
          liftedEarly: ipBanHistoryTable.liftedEarly,
        })
        .from(ipBanHistoryTable)
        .where(gte(ipBanHistoryTable.bannedAt, cutoff))
        .orderBy(desc(ipBanHistoryTable.bannedAt));

      res.json(
        rows.map((r) => ({
          ip: r.ip,
          blockedAt: new Date(r.bannedAt).toISOString(),
          blockedUntil: new Date(r.until).toISOString(),
          unblockedAt: r.unbannedAt != null ? new Date(r.unbannedAt).toISOString() : null,
          reason: r.reason ?? null,
          liftedEarly: r.liftedEarly,
        })),
      );
    } catch {
      res.status(500).json({ error: "Failed to retrieve ban history" });
    }
    return;
  }

  try {
    const now = Date.now();

    const activeBans = await db
      .select({ ip: ipBansTable.ip, until: ipBansTable.until })
      .from(ipBansTable)
      .where(gt(ipBansTable.until, now));

    const active = activeBans.map((b) => ({
      ip: b.ip,
      blockedUntil: new Date(b.until).toISOString(),
      active: true,
    }));

    res.json(active);
  } catch {
    res.status(500).json({ error: "Failed to retrieve bans" });
  }
});

/**
 * GET /api/admin/bans/history
 * Returns past bans from the last 30 days, newest first.
 * Each record includes ip, blockedAt, unblockedAt (null if not yet lifted), and reason.
 */
router.get("/bans/history", async (req, res) => {
  try {
    const cutoff = Date.now() - HISTORY_RETENTION_MS;

    const rows = await db
      .select({
        ip: ipBanHistoryTable.ip,
        bannedAt: ipBanHistoryTable.bannedAt,
        until: ipBanHistoryTable.until,
        unbannedAt: ipBanHistoryTable.unbannedAt,
        reason: ipBanHistoryTable.reason,
        liftedEarly: ipBanHistoryTable.liftedEarly,
      })
      .from(ipBanHistoryTable)
      .where(gte(ipBanHistoryTable.bannedAt, cutoff))
      .orderBy(desc(ipBanHistoryTable.bannedAt));

    res.json(
      rows.map((r) => ({
        ip: r.ip,
        blockedAt: new Date(r.bannedAt).toISOString(),
        blockedUntil: new Date(r.until).toISOString(),
        unblockedAt: r.unbannedAt != null ? new Date(r.unbannedAt).toISOString() : null,
        reason: r.reason ?? null,
        liftedEarly: r.liftedEarly,
      })),
    );
  } catch {
    res.status(500).json({ error: "Failed to retrieve ban history" });
  }
});

/**
 * DELETE /api/admin/bans/:ip
 * Manually lifts a ban. Records the unban in history with reason="manual".
 */
router.delete("/bans/:ip", async (req, res) => {
  const { ip } = req.params;

  try {
    const [existing] = await db
      .select({ ip: ipBansTable.ip, until: ipBansTable.until })
      .from(ipBansTable)
      .where(eq(ipBansTable.ip, ip));

    if (!existing) {
      res.status(404).json({ error: "No active ban found for that IP" });
      return;
    }

    await archiveBan(existing.ip, existing.until, "manual");
    res.json({ message: `Ban removed for ${ip}` });
  } catch {
    res.status(500).json({ error: "Failed to remove ban" });
  }
});

export default router;
